<template>
  <div id="house-types">
    房屋类型
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'HouseTypes'
}
</script>
