<template>
  <div id="house-details">
    房屋详情
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'HouseDetails',
  created() {
    console.log(this.$router, 'mmmmmmm')
  },
  beforeRouteEnter(to, from, next) {
    console.log(to, '55555555')
    next()
  }
}
</script>
