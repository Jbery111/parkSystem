<template>
  <div id="car">
    车位信息页面
  </div>
</template>

<script>
export default {
  name: 'Car'
}
</script>
