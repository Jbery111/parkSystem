<template>
  <div id="charge">
    物业收费页面
  </div>
</template>

<script>
export default {
  name: 'Charge'
}
</script>
