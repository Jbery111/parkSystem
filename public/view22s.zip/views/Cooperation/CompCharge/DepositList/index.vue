<template>
  <div id="deposit-list">
    押金列表
  </div>
</template>

<script>
export default {
  name: 'DepositList'
}
</script>
