<template>
  <div id="compcharge">
    企业收费
    <!-- 三级菜单出口 -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'CompCharge'
}
</script>
