<template>
  <div id="enterprise-info">
    企业信息
  </div>
</template>

<script>
export default {
  name: 'EnterpriseInfo'
}
</script>
