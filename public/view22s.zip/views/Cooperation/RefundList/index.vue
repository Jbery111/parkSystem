<template>
  <div id="refund-list">
    退款列表
  </div>
</template>

<script>
export default {
  name: 'RefundList'
}
</script>
