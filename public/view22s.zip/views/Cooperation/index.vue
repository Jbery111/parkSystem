<template>
  <div id="cooperation">
    企业合作
    <!-- 二级菜单出口 -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'Cooperation'
}
</script>
