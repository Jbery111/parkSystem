<template>
  <div id="review-list">
    审核列表
  </div>
</template>

<script>
export default {
  name: 'ReviewList'
}
</script>
