<template>
  <div class="wy-homepage">
    <div class="wy-container">
      首页qqqqqqqqqq
    </div>
  </div>
</template>

<script>
/* eslint-disable */
export default {
  
}
</script>

<style lang="scss" scoped>
  body,html {
    // position: fixed;
    width: 100%;
    height: 100%;
  }
</style>